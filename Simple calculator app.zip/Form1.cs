﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Calculatorbody : Form
    {
        bool operandPerformed = false;
        string operand = "";
        double result = 0;
        public Calculatorbody()
        {
            InitializeComponent();
        }

        private void NumEvent(object sender, EventArgs e)
        {
          
            if (txtResult.Text == "0" || operandPerformed)
                txtResult.Clear();

            Button btn = (Button)sender;
            txtResult.Text += btn.Text;
            operandPerformed = false;
        }

        private void OperandEvent(object sender, EventArgs e)
        {
            operandPerformed = true;
            Button btn = (Button)sender;
            string newOperand = btn.Text;

            lbResult.Text = lbResult.Text + " " + txtResult.Text + " " + newOperand;

            switch (operand)
            {
                case "+": txtResult.Text = (result + Double.Parse(txtResult.Text)).ToString(); break;
                case "-": txtResult.Text = (result - Double.Parse(txtResult.Text)).ToString(); break;
                case "*": txtResult.Text = (result * Double.Parse(txtResult.Text)).ToString(); break;
                case "/": txtResult.Text = (result / Double.Parse(txtResult.Text)).ToString(); break;
                case "^": txtResult.Text = (Math.Pow(result, Double.Parse(txtResult.Text))).ToString(); break;
                default:break;
            }

          
            result = Double.Parse(txtResult.Text);
            operand = newOperand;
        }

        private void UndoNumber(object sender, EventArgs e)
        {
            if (txtResult.Text != null)
            {
                if (txtResult.Text.Length <= 1 || (txtResult.Text.Length == 2 || txtResult.Text[0] != '-'))
                {
                    txtResult.Text = "0";
                }
                else
                {
                    txtResult.Text = txtResult.Text.Remove(txtResult.Text.Length - 1, 1);
                }
            }
        }
        
        private void ButtonCE_Click(object sender, EventArgs e)
        {
            txtResult.Text = "0";
        }

        private void ButtonC_Click(object sender, EventArgs e)
        {
            txtResult.Text = "0";
            lbResult.Text = "";
            result = 0;
            operand = "";
        }

        private void ButtonResult_Click(object sender, EventArgs e)
        {
            lbResult.Text = "";
            operandPerformed = true;

            switch (operand)
            {
                case "+": txtResult.Text = (result + Double.Parse(txtResult.Text)).ToString(); break;
                case "-": txtResult.Text = (result - Double.Parse(txtResult.Text)).ToString(); break;
                case "*": txtResult.Text = (result * Double.Parse(txtResult.Text)).ToString(); break;
                case "/": txtResult.Text = (result / Double.Parse(txtResult.Text)).ToString(); break;
                case "^": txtResult.Text = (Math.Pow(result, Double.Parse(txtResult.Text))).ToString(); break;
                default: break;
            }

            result = Double.Parse(txtResult.Text);
            txtResult.Text = result.ToString();
            result = 0;
            operand = "";
        }

        private void ButtonDot_Click(object sender, EventArgs e)
        {
            if(!operandPerformed && !txtResult.Text.Contains(","))
            {
                txtResult.Text += ",";
            }
            else if(operandPerformed)
            {
                txtResult.Text = "0";
            }
            
            if(!txtResult.Text.Contains(","))
            {
                txtResult.Text += ",";
            }

            operandPerformed = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void TxtResult_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

